<?php get_header(); ?>

<?php if ( have_posts() ) :
  if ( is_home() || is_archive() ) : ?>
    <section class="posts-list">
      <?php while ( have_posts() ) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>">
          <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
          <div class="entry-summary"><?php the_excerpt(); ?></div>
        </article>
      <?php endwhile; ?>
    </section>
  <?php else :
    while ( have_posts() ) : the_post(); ?>
      <article id="post-<?php the_ID(); ?>">
        <h1><?php the_title(); ?></h1>
        <div class="entry-content"><?php the_content(); ?></div>
      </article>
    <?php endwhile;
  endif;
else :
  echo '<p>No content found.</p>';
endif;

<?php get_footer(); ?>
