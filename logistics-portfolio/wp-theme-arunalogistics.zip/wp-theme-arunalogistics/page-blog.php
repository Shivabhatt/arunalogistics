<?php
/**
 * Template Name: Blog Page
 * Description: Static blog listing (replaces Next.js blog page)
 */
get_header();
?>

<!-- Hero -->
<section class="relative pt-32 pb-20 bg-gradient-to-br from-slate-900 via-purple-900 to-orange-900 overflow-hidden">
  <div class="absolute inset-0 opacity-10"><svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="bGrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(#bGrid)"/></svg></div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center max-w-4xl mx-auto">
    <div class="inline-flex items-center justify-center w-20 h-20 bg-white/10 backdrop-blur-sm rounded-3xl mb-6 text-4xl">📖</div>
    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">Our <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-purple-400">Blog &amp; Insights</span></h1>
    <p class="text-xl text-slate-300 mb-8">Expert insights, industry trends, and tips to optimize your logistics and supply chain operations.</p>
  </div>
</section>

<!-- Blog Posts (WordPress loop or static fallback) -->
<section class="py-16 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <?php
    // Use WP posts if available, otherwise show static content
    $blog_query = new WP_Query(array('post_type'=>'post','posts_per_page'=>9));
    if ($blog_query->have_posts()):
    ?>
    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
      <?php while ($blog_query->have_posts()): $blog_query->the_post(); ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-lg transition-all duration-300">
        <?php if (has_post_thumbnail()): ?>
        <div class="w-full h-48 rounded-xl mb-6 overflow-hidden"><img src="<?php echo esc_url(get_the_post_thumbnail_url(null,'medium_large')); ?>" alt="<?php the_title_attribute(); ?>" class="w-full h-full object-cover"></div>
        <?php else: ?>
        <div class="w-full h-48 bg-gradient-to-br from-slate-100 to-slate-200 rounded-xl mb-6 flex items-center justify-center text-6xl">📝</div>
        <?php endif; ?>
        <h3 class="text-xl font-bold text-slate-900 mb-3 hover:text-orange-500 transition-colors"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <p class="text-slate-600 mb-4 line-clamp-3"><?php echo wp_trim_words(get_the_excerpt(), 25); ?></p>
        <div class="flex items-center justify-between text-sm text-slate-500 pt-4 border-t border-slate-100">
          <span><?php the_author(); ?></span>
          <span><?php echo get_the_date(); ?></span>
        </div>
      </div>
      <?php endwhile; wp_reset_postdata(); ?>
    </div>
    <?php else: ?>
    <!-- Static fallback blog posts -->
    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
      <?php
      $static_posts = [
        ['💰','How to Reduce Shipping Costs Without Compromising Speed','Discover proven strategies to optimize your shipping expenses.','Rahul Sharma','February 5, 2026','Tips & Guides'],
        ['🤖','Warehouse Automation: A Complete Guide','From robotic picking systems to AI inventory management.','Priya Patel','January 28, 2026','Technology'],
        ['🔗','Building a Resilient Supply Chain','Key strategies for creating supply chain resilience.','Vikram Singh','January 20, 2026','Supply Chain'],
        ['🚀','Aruna Logistics Expands to 50 New Cities','Bringing our total coverage to 250+ cities nationwide.','Aruna Team','January 15, 2026','Company News'],
        ['🌱','Sustainable Logistics: Reducing Carbon Footprint','Eco-friendly packaging and electric delivery vehicles.','Anita Desai','January 8, 2026','Industry Insights'],
        ['📍','Real-Time Tracking: Why Visibility Matters','How tracking improves customer satisfaction and reduces support tickets.','Rahul Sharma','December 30, 2025','Technology'],
      ];
      foreach ($static_posts as $post): ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-lg transition-all duration-300 cursor-pointer">
        <div class="w-full h-48 bg-gradient-to-br from-slate-100 to-slate-200 rounded-xl mb-6 flex items-center justify-center text-6xl"><?php echo $post[0]; ?></div>
        <div class="flex items-center gap-2 mb-3"><span class="text-sm font-medium text-orange-600"><?php echo esc_html($post[5]); ?></span></div>
        <h3 class="text-xl font-bold text-slate-900 mb-3 hover:text-orange-500 transition-colors"><?php echo esc_html($post[1]); ?></h3>
        <p class="text-slate-600 mb-4"><?php echo esc_html($post[2]); ?></p>
        <div class="flex items-center justify-between text-sm text-slate-500 pt-4 border-t border-slate-100">
          <span><?php echo esc_html($post[3]); ?></span>
          <span><?php echo esc_html($post[4]); ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>

<!-- Newsletter CTA -->
<section class="py-20 bg-gradient-to-br from-slate-900 to-purple-900">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center max-w-3xl mx-auto">
    <div class="text-5xl mb-6">📖</div>
    <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">Stay Updated with Our Newsletter</h2>
    <p class="text-xl text-slate-300 mb-8">Get the latest logistics insights delivered to your inbox every week.</p>
    <div class="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
      <input type="email" placeholder="Enter your email" class="flex-1 px-6 py-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent">
      <button class="inline-flex items-center justify-center font-semibold rounded-lg bg-orange-500 text-white hover:bg-orange-600 shadow-lg px-8 py-4 text-lg transition-all duration-300">Subscribe</button>
    </div>
    <p class="text-sm text-slate-400 mt-4">No spam. Unsubscribe anytime.</p>
  </div>
</section>

<?php get_footer(); ?>
