<?php
// Theme functions for Aruna Logistics

if ( ! function_exists( 'aruna_setup' ) ) :
  function aruna_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
    register_nav_menus( array(
      'primary' => __( 'Primary Menu', 'arunalogistics' ),
    ) );
  }
endif;
add_action( 'after_setup_theme', 'aruna_setup' );

function aruna_enqueue_assets() {
  $theme_uri = get_stylesheet_directory_uri();
  $theme_dir = get_stylesheet_directory();

  // Theme stylesheet (WP required style.css)
  wp_enqueue_style( 'aruna-style', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );

  // Custom CSS (scrollbar, animations)
  $css_file = $theme_dir . '/assets/theme.css';
  if ( file_exists( $css_file ) ) {
    wp_enqueue_style( 'aruna-theme-css', $theme_uri . '/assets/theme.css', array(), filemtime( $css_file ) );
  }

  // Main JS (mobile menu, header scroll)
  wp_enqueue_script( 'aruna-main', $theme_uri . '/assets/main.js', array(), filemtime( $theme_dir . '/assets/main.js' ), true );
}
add_action( 'wp_enqueue_scripts', 'aruna_enqueue_assets' );

/**
 * Auto-create pages and assign custom templates on theme activation.
 */
function aruna_create_pages() {
  $pages = array(
    'Home'     => array( 'slug' => 'home',     'template' => '' ),
    'About'    => array( 'slug' => 'about',    'template' => 'page-about.php' ),
    'Services' => array( 'slug' => 'services', 'template' => 'page-services.php' ),
    'Process'  => array( 'slug' => 'process',  'template' => 'page-process.php' ),
    'Pricing'  => array( 'slug' => 'pricing',  'template' => 'page-pricing.php' ),
    'Blog'     => array( 'slug' => 'blog',     'template' => 'page-blog.php' ),
    'Contact'  => array( 'slug' => 'contact',  'template' => 'page-contact.php' ),
    'Quote'    => array( 'slug' => 'quote',    'template' => 'page-quote.php' ),
  );
  foreach ( $pages as $title => $data ) {
    $existing = get_page_by_path( $data['slug'] );
    if ( ! $existing ) {
      $page_id = wp_insert_post( array(
        'post_title'   => $title,
        'post_name'    => $data['slug'],
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_content' => '',
      ) );
      if ( $page_id && ! is_wp_error( $page_id ) && $data['template'] ) {
        update_post_meta( $page_id, '_wp_page_template', $data['template'] );
      }
    }
  }

  // Set "Home" page as static front page
  $home_page = get_page_by_path( 'home' );
  if ( $home_page ) {
    update_option( 'show_on_front', 'page' );
    update_option( 'page_on_front', $home_page->ID );
  }
}
add_action( 'after_switch_theme', 'aruna_create_pages' );
