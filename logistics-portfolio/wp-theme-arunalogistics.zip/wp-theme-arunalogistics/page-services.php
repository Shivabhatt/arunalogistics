<?php
/**
 * Template Name: Services Page
 */
get_header();
?>

<!-- Hero -->
<section class="relative pt-32 pb-20 bg-gradient-to-br from-slate-900 via-slate-900 to-purple-900 overflow-hidden">
  <div class="absolute inset-0 opacity-10"><svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="sGrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(#sGrid)"/></svg></div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center max-w-4xl mx-auto">
    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">Comprehensive <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-purple-400">Logistics Solutions</span></h1>
    <p class="text-xl text-slate-300 mb-8">From express parcels to international freight, we offer end-to-end logistics services tailored to your business needs.</p>
    <div class="flex flex-col sm:flex-row gap-4 justify-center">
      <a href="<?php echo esc_url( home_url('/contact') ); ?>" class="inline-flex items-center justify-center font-semibold rounded-lg bg-orange-500 text-white hover:bg-orange-600 shadow-lg px-8 py-4 text-lg transition-all duration-300">Get Started Today</a>
      <a href="<?php echo esc_url( home_url('/quote') ); ?>" class="inline-flex items-center justify-center font-semibold rounded-lg border-2 border-white text-white hover:bg-white/10 px-8 py-4 text-lg transition-all duration-300">Request a Quote</a>
    </div>
  </div>
</section>

<!-- Core Services -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Our Core Services</h2>
      <p class="text-lg text-slate-600 max-w-3xl mx-auto">Comprehensive logistics solutions designed to streamline your operations.</p>
    </div>
    <div class="grid lg:grid-cols-2 gap-8">
      <?php
      $main_services = [
        ['🚚','Express Parcel Delivery','Lightning-fast same-day and next-day delivery.','40% faster than standard shipping',['Same-day delivery in major cities','Next-day nationwide coverage','Real-time tracking','Proof of delivery','Flexible pickup options']],
        ['📦','Freight & Cargo Services','Comprehensive freight solutions for businesses of all sizes.','Save up to 35% on bulk shipments',['Part Truckload (PTL) solutions','Full Truckload (FTL) services','Containerized shipping','Hazmat handling','Temperature-controlled transport']],
        ['🏭','Warehousing & Fulfillment','State-of-the-art storage and order fulfillment solutions.','99.8% order accuracy',['Multi-location warehouses','Inventory management','Order processing & packing','Returns handling','Same-day fulfillment']],
        ['🌐','International Shipping','Ship globally with confidence to 220+ countries.','Ship to 220+ countries',['Air freight services','Ocean freight','Customs clearance','Import/export documentation','Door-to-door delivery']],
        ['📍','Last-Mile Delivery','Efficient final-mile solutions for urban and rural areas.','96% first-attempt success',['Same-day last-mile','Scheduled deliveries','Contactless delivery','Signature on delivery','Failed delivery management']],
        ['🔄','Returns Management','Streamlined reverse logistics for hassle-free returns.','Reduce RTO by 40%',['Easy return pickup','Quality inspection','Refund processing','Inventory restocking','Analytics & reporting']],
      ];
      foreach ($main_services as $svc): ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-lg transition-all duration-300">
        <div class="flex items-start gap-4 mb-6">
          <div class="flex-shrink-0 w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-100 to-orange-50 flex items-center justify-center text-3xl"><?php echo $svc[0]; ?></div>
          <div class="flex-grow">
            <h3 class="text-2xl font-bold text-slate-900 mb-2"><?php echo esc_html($svc[1]); ?></h3>
            <p class="text-slate-600 mb-4"><?php echo esc_html($svc[2]); ?></p>
            <div class="inline-flex px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm font-semibold"><?php echo esc_html($svc[3]); ?></div>
          </div>
        </div>
        <div class="space-y-3 mb-6">
          <h4 class="font-semibold text-slate-900">Key Features:</h4>
          <?php foreach ($svc[4] as $feat): ?>
          <div class="flex items-start gap-2"><span class="text-green-500 flex-shrink-0">✓</span><span class="text-slate-600"><?php echo esc_html($feat); ?></span></div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Additional Services -->
<section class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Additional Services</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">Enhance your logistics operations with our value-added services.</p>
    </div>
    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
      <?php foreach ([['🛡️','Cargo Insurance','Comprehensive protection for your shipments'],['⏰','Time-Definite Services','Guaranteed delivery within specified timeframes'],['💵','COD Services','Cash on delivery with quick remittance'],['📊','Analytics Dashboard','Real-time insights into your logistics operations'],['🎧','24/7 Support','Round-the-clock customer service'],['⚡','API Integration','Seamless integration with your systems']] as $as): ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 text-center hover:shadow-lg transition-all duration-300">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-100 to-purple-50 mb-4 text-3xl"><?php echo $as[0]; ?></div>
        <h3 class="text-xl font-bold text-slate-900 mb-2"><?php echo esc_html($as[1]); ?></h3>
        <p class="text-slate-600"><?php echo esc_html($as[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="py-20 bg-gradient-to-br from-orange-500 to-purple-600">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
    <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">Ready to Optimize Your Logistics?</h2>
    <p class="text-xl mb-8 max-w-2xl mx-auto opacity-90">Partner with us and experience the difference.</p>
    <div class="flex flex-col sm:flex-row gap-4 justify-center">
      <a href="<?php echo esc_url( home_url('/contact') ); ?>" class="inline-flex items-center justify-center font-semibold rounded-lg bg-white text-slate-900 hover:bg-slate-100 shadow-lg px-8 py-4 text-lg transition-all duration-300">Contact Our Team</a>
      <a href="<?php echo esc_url( home_url('/quote') ); ?>" class="inline-flex items-center justify-center font-semibold rounded-lg border-2 border-white text-white hover:bg-white/10 px-8 py-4 text-lg transition-all duration-300">Get a Free Quote</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
