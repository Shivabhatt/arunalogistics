# Aruna Logistics — WordPress Theme

A fully-featured WordPress theme converted from the Next.js `logistics-portfolio` project. Uses the **Tailwind CSS Play CDN** — no build step required.

---

## Quick Install

1. **Zip the theme folder** (if not already zipped):
   ```bash
   cd /path/to/logistics-portfolio
   zip -r wp-theme-arunalogistics.zip wp-theme-arunalogistics/
   ```

2. **Upload to WordPress**:
   - Go to **Appearance → Themes → Add New → Upload Theme**
   - Select `wp-theme-arunalogistics.zip`
   - Click **Install Now**, then **Activate**

3. **Done!** On activation the theme automatically:
   - Creates pages: Home, About, Services, Process, Pricing, Blog, Contact, Quote
   - Assigns the correct page template to each page
   - Sets the Home page as the static front page

---

## What's Included

| File | Purpose |
|---|---|
| `style.css` | WP theme header + custom CSS (scrollbar, animations) |
| `functions.php` | Theme setup, asset loading, auto page creation |
| `header.php` | Responsive header with mobile menu, Tailwind CDN, Inter font |
| `footer.php` | Full footer with links, social icons, copyright |
| `front-page.php` | Home page (Hero, Partners, Stats, Services, WhyUs, Testimonials, Case Studies, CTA, Contact) |
| `page-about.php` | About page (Story, Mission, Values, Team, Journey) |
| `page-services.php` | Services page (Core services, additional services) |
| `page-process.php` | Process page (6-step process) |
| `page-pricing.php` | Pricing page (3 plans, add-ons, FAQ) |
| `page-blog.php` | Blog page (WP posts or static fallback) |
| `page-contact.php` | Contact page (form, offices, map) |
| `page-quote.php` | Quote request page (detailed form) |
| `page.php` | Generic page template |
| `single.php` | Single post template |
| `index.php` | Fallback archive/loop |
| `assets/main.js` | Mobile menu toggle, header scroll effect |

---

## Setting Up the Menu

The header has a built-in fallback navigation, but you can also create a custom menu:

1. Go to **Appearance → Menus**
2. Create a new menu (e.g. "Main Menu")
3. Add the auto-created pages
4. Assign to the **Primary Menu** location

---

## Permalink Settings

For clean URLs (`/about`, `/services`, etc.):

1. Go to **Settings → Permalinks**
2. Select **Post name** (`/%postname%/`)
3. Save

---

## Tailwind CSS

This theme uses the **Tailwind CSS Play CDN** (loaded via `<script>` tag in `header.php`):

- No build step required
- All Tailwind utility classes work out of the box
- For production at scale, consider a Tailwind build pipeline to generate a static CSS file

---

## Customization Tips

- **Logo**: Edit the header in `header.php` — replace the "A" icon with your own image
- **Colors**: Modify the Tailwind config in the `header.php` `<script>` block
- **Content**: Edit the PHP arrays in each page template to update text, stats, team members, etc.
- **Contact forms**: Forms submit to `#` — connect to Contact Form 7 or WPForms
- **Blog**: Automatically uses WordPress posts when available, with static fallback
