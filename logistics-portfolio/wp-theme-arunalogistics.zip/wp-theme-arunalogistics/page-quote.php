<?php
/**
 * Template Name: Quote Page
 */
get_header();
?>

<!-- Hero -->
<section class="relative pt-32 pb-20 bg-gradient-to-br from-orange-500 via-orange-600 to-purple-600 overflow-hidden">
  <div class="absolute inset-0 opacity-20"><svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="qGrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(#qGrid)"/></svg></div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center max-w-4xl mx-auto text-white">
    <div class="text-5xl mb-6">📦</div>
    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">Get Your Free Shipping Quote</h1>
    <p class="text-xl mb-8 opacity-90">Compare rates from 50+ carriers instantly. No commitments, no hidden fees.</p>
    <div class="flex flex-wrap justify-center gap-4 text-sm">
      <?php foreach (['Instant rate comparison','No hidden fees','Free pickup available','Insurance included','24/7 tracking','Dedicated support'] as $b): ?>
      <div class="flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full"><span>✓</span><span><?php echo esc_html($b); ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Quote Form -->
<section class="py-20 bg-white">
  <div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid lg:grid-cols-3 gap-12">
      <div class="lg:col-span-2">
        <div class="bg-white rounded-xl border-2 border-orange-100 shadow-xl p-8">
          <div class="mb-8">
            <h2 class="text-3xl font-bold text-slate-900 mb-2">Request a Quote</h2>
            <p class="text-slate-600">Fill in the details below and we'll get back to you within 30 minutes.</p>
          </div>
          <form class="space-y-6" method="post">
            <div class="grid sm:grid-cols-2 gap-6">
              <div><label class="block text-sm font-medium text-slate-700 mb-2">Full Name *</label><input type="text" name="name" placeholder="John Doe" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
              <div><label class="block text-sm font-medium text-slate-700 mb-2">Email *</label><input type="email" name="email" placeholder="john@company.com" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
            </div>
            <div class="grid sm:grid-cols-2 gap-6">
              <div><label class="block text-sm font-medium text-slate-700 mb-2">Phone *</label><input type="tel" name="phone" placeholder="+1 (555) 000-0000" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
              <div><label class="block text-sm font-medium text-slate-700 mb-2">Company</label><input type="text" name="company" placeholder="Your Company" class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
            </div>
            <div>
              <label class="block text-sm font-medium text-slate-700 mb-3">Service Type *</label>
              <div class="grid grid-cols-3 gap-4">
                <?php foreach ([['🚚','Express Delivery','Same-day & next-day'],['📦','Standard Shipping','2-5 business days'],['🌐','International','Worldwide shipping']] as $st): ?>
                <label class="p-4 rounded-lg border-2 border-slate-200 text-center cursor-pointer hover:border-orange-300 transition-all has-[:checked]:border-orange-500 has-[:checked]:bg-orange-50">
                  <input type="radio" name="service_type" value="<?php echo esc_attr(strtolower($st[1])); ?>" class="sr-only" <?php if ($st[1]==='Express Delivery') echo 'checked'; ?>>
                  <div class="text-2xl mb-2"><?php echo $st[0]; ?></div>
                  <div class="font-semibold text-slate-900 text-sm mb-1"><?php echo esc_html($st[1]); ?></div>
                  <div class="text-xs text-slate-500"><?php echo esc_html($st[2]); ?></div>
                </label>
                <?php endforeach; ?>
              </div>
            </div>
            <div class="grid sm:grid-cols-2 gap-6">
              <div><label class="block text-sm font-medium text-slate-700 mb-2">From ZIP Code *</label><input type="text" name="from_zip" placeholder="10001" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
              <div><label class="block text-sm font-medium text-slate-700 mb-2">To ZIP Code *</label><input type="text" name="to_zip" placeholder="90001" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
            </div>
            <div class="grid sm:grid-cols-2 gap-6">
              <div><label class="block text-sm font-medium text-slate-700 mb-2">Weight (lbs) *</label><input type="text" name="weight" placeholder="10" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
              <div><label class="block text-sm font-medium text-slate-700 mb-2">Quantity</label><input type="number" name="quantity" placeholder="1" value="1" class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
            </div>
            <div><label class="block text-sm font-medium text-slate-700 mb-2">Dimensions (L x W x H in inches)</label><input type="text" name="dimensions" placeholder="12 x 8 x 6" class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
            <button type="submit" class="w-full inline-flex items-center justify-center font-semibold rounded-lg bg-orange-500 text-white hover:bg-orange-600 shadow-lg px-8 py-4 text-lg transition-all duration-300">Submit Quote Request</button>
          </form>
        </div>
      </div>
      <!-- Sidebar -->
      <div class="space-y-6">
        <div class="bg-gradient-to-br from-slate-900 to-purple-900 text-white rounded-xl border border-slate-200 shadow-sm p-6">
          <h3 class="text-xl font-bold mb-4">Why Choose Us?</h3>
          <div class="space-y-4">
            <?php foreach ([['⏱️','99.5% On-Time','Delivery success rate'],['🛡️','Insured Shipments','Up to $10,000 coverage'],['🚚','50+ Carriers','Best rates guaranteed']] as $feat): ?>
            <div class="flex items-start gap-3">
              <div class="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center flex-shrink-0"><?php echo $feat[0]; ?></div>
              <div><div class="font-semibold mb-1"><?php echo esc_html($feat[1]); ?></div><div class="text-sm text-slate-300"><?php echo esc_html($feat[2]); ?></div></div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
          <h3 class="text-lg font-bold text-slate-900 mb-3">Need Help?</h3>
          <p class="text-slate-600 mb-4 text-sm">Our logistics experts are available to help you find the best solution.</p>
          <a href="<?php echo esc_url( home_url('/contact') ); ?>" class="w-full inline-flex items-center justify-center font-semibold rounded-lg border-2 border-slate-300 text-slate-700 hover:bg-slate-50 px-4 py-2 text-sm transition-all duration-300">Contact Support</a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
