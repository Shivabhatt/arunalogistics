<?php
/**
 * Template Name: Pricing Page
 */
get_header();
?>

<!-- Hero -->
<section class="relative pt-32 pb-20 bg-gradient-to-br from-slate-900 via-slate-900 to-purple-900 overflow-hidden">
  <div class="absolute inset-0 opacity-10"><svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="pGrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(#pGrid)"/></svg></div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center max-w-4xl mx-auto">
    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">Simple, <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-purple-400">Transparent Pricing</span></h1>
    <p class="text-xl text-slate-300 mb-8">Choose the plan that fits your business. All plans include our core features with no hidden fees.</p>
  </div>
</section>

<!-- Pricing Plans -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid lg:grid-cols-3 gap-8">
      <?php
      $plans = [
        ['Starter','⚡','$49','/month','Perfect for small businesses and startups',['Up to 100 shipments/month','Standard shipping rates','Basic tracking','Email support','Dashboard access','5% platform fee'],false,'Start Free Trial'],
        ['Business','🏢','$149','/month','Ideal for growing businesses',['Up to 1,000 shipments/month','Discounted shipping rates','Advanced tracking & analytics','Priority support','API access','Multi-user accounts','3% platform fee','Free branded tracking page'],true,'Get Started'],
        ['Enterprise','🚀','Custom','','For large-scale operations',['Unlimited shipments','Lowest shipping rates','Custom integrations','Dedicated account manager','White-label solutions','Advanced analytics','SLA guarantee','Priority processing','Custom workflows'],false,'Contact Sales'],
      ];
      foreach ($plans as $plan): ?>
      <div class="relative bg-white rounded-xl border <?php echo $plan[6] ? 'border-2 border-orange-500 shadow-2xl lg:scale-105' : 'border-slate-200 shadow-sm'; ?> p-6 hover:shadow-lg transition-all duration-300">
        <?php if ($plan[6]): ?>
        <div class="absolute -top-4 left-1/2 -translate-x-1/2"><span class="bg-gradient-to-r from-orange-500 to-purple-600 text-white px-6 py-2 rounded-full text-sm font-semibold">Most Popular</span></div>
        <?php endif; ?>
        <div class="text-center mb-6">
          <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4 text-3xl <?php echo $plan[6] ? 'bg-gradient-to-br from-orange-500 to-purple-600' : 'bg-gradient-to-br from-slate-100 to-slate-200'; ?>"><?php echo $plan[1]; ?></div>
          <h3 class="text-2xl font-bold text-slate-900 mb-2"><?php echo esc_html($plan[0]); ?></h3>
          <p class="text-slate-600 mb-4"><?php echo esc_html($plan[4]); ?></p>
          <div class="mb-6"><span class="text-5xl font-bold text-slate-900"><?php echo esc_html($plan[2]); ?></span><span class="text-slate-600"><?php echo esc_html($plan[3]); ?></span></div>
        </div>
        <div class="space-y-3 mb-8">
          <?php foreach ($plan[5] as $feat): ?>
          <div class="flex items-start gap-3"><span class="text-green-500 flex-shrink-0 mt-0.5">✓</span><span class="text-slate-600"><?php echo esc_html($feat); ?></span></div>
          <?php endforeach; ?>
        </div>
        <a href="<?php echo esc_url( home_url('/quote') ); ?>" class="w-full inline-flex items-center justify-center font-semibold rounded-lg <?php echo $plan[6] ? 'bg-orange-500 text-white hover:bg-orange-600 shadow-lg' : 'border-2 border-slate-300 text-slate-700 hover:bg-slate-50'; ?> px-6 py-3 text-base transition-all duration-300"><?php echo esc_html($plan[7]); ?> &rarr;</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Add-On Services -->
<section class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Add-On Services</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">Enhance your shipping with optional value-added services.</p>
    </div>
    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
      <?php foreach ([['Cargo Insurance','From $5/shipment'],['Expedited Processing','$10/shipment'],['Weekend Pickup','$15/pickup'],['COD Services','2% of order value'],['Returns Management','$2/return'],['Additional Packaging','From $3/box']] as $addon): ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 flex items-center justify-between hover:shadow-lg transition-all duration-300">
        <span class="font-semibold text-slate-900"><?php echo esc_html($addon[0]); ?></span>
        <span class="text-orange-600 font-bold"><?php echo esc_html($addon[1]); ?></span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- FAQ -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16"><h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Frequently Asked Questions</h2></div>
    <div class="max-w-3xl mx-auto space-y-6">
      <?php foreach ([['Can I change plans at any time?','Yes, you can upgrade or downgrade at any time. Changes take effect immediately with prorated billing.'],['Is there a contract or commitment?','No, all plans are month-to-month with no long-term contracts.'],['What payment methods do you accept?','All major credit/debit cards and ACH bank transfers for enterprise customers.'],['Do you offer volume discounts?','Yes, we offer custom pricing for high-volume shippers. Contact our sales team.']] as $faq): ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 class="text-lg font-bold text-slate-900 mb-2"><?php echo esc_html($faq[0]); ?></h3>
        <p class="text-slate-600"><?php echo esc_html($faq[1]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="py-20 bg-gradient-to-br from-orange-500 to-purple-600">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
    <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">Still Have Questions?</h2>
    <p class="text-xl mb-8 max-w-2xl mx-auto opacity-90">Our team is here to help you find the perfect plan.</p>
    <div class="flex flex-col sm:flex-row gap-4 justify-center">
      <a href="<?php echo esc_url( home_url('/contact') ); ?>" class="inline-flex items-center justify-center font-semibold rounded-lg bg-white text-slate-900 hover:bg-slate-100 shadow-lg px-8 py-4 text-lg transition-all duration-300">Contact Sales</a>
      <a href="<?php echo esc_url( home_url('/quote') ); ?>" class="inline-flex items-center justify-center font-semibold rounded-lg border-2 border-white text-white hover:bg-white/10 px-8 py-4 text-lg transition-all duration-300">Get a Quote</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
