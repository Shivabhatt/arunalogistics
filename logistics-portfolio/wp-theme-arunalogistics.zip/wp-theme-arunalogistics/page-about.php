<?php
/**
 * Template Name: About Page
 */
get_header();
?>

<!-- Hero -->
<section class="relative pt-32 pb-20 bg-gradient-to-br from-slate-900 via-slate-900 to-purple-900 overflow-hidden">
  <div class="absolute inset-0 opacity-10"><svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="aboutGrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(#aboutGrid)"/></svg></div>
  <div class="absolute top-20 left-10 w-72 h-72 bg-purple-500 rounded-full filter blur-[128px] opacity-30"></div>
  <div class="absolute bottom-20 right-10 w-96 h-96 bg-orange-500 rounded-full filter blur-[128px] opacity-20"></div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center max-w-3xl mx-auto">
    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">About <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-purple-400">Aruna Logistics Solution</span></h1>
    <p class="text-lg sm:text-xl text-slate-300">We're on a mission to make logistics simple, affordable, and accessible for businesses of all sizes.</p>
  </div>
</section>

<!-- Story -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid lg:grid-cols-2 gap-16 items-center">
      <div>
        <h2 class="text-3xl sm:text-4xl font-bold text-slate-900 mb-6">Our Story</h2>
        <div class="space-y-4 text-slate-600 text-lg leading-relaxed">
          <p>Aruna Logistics Solution was founded in 2018 with a simple belief: every business deserves access to world-class logistics solutions, regardless of size.</p>
          <p>What started as a small team with big dreams has grown into a comprehensive logistics platform serving over 500 brands across 200+ cities.</p>
          <p>Today, we process millions of shipments annually, helping businesses save time, reduce costs, and delight their customers.</p>
        </div>
      </div>
      <div class="bg-gradient-to-br from-orange-100 to-purple-100 rounded-2xl p-8">
        <div class="grid grid-cols-2 gap-6">
          <?php foreach ([['500+','Brand Partners','orange'],['1M+','Shipments','purple'],['200+','Cities','blue'],['50+','Carriers','green']] as $s): ?>
          <div class="bg-white rounded-xl p-6 shadow-sm text-center">
            <p class="text-4xl font-bold text-<?php echo $s[2]; ?>-500 mb-2"><?php echo esc_html($s[0]); ?></p>
            <p class="text-slate-600"><?php echo esc_html($s[1]); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Mission & Vision -->
<section class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid md:grid-cols-2 gap-8">
      <div class="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm h-full">
        <div class="w-14 h-14 rounded-2xl bg-orange-100 flex items-center justify-center mb-6 text-2xl">🎯</div>
        <h3 class="text-2xl font-bold text-slate-900 mb-4">Our Mission</h3>
        <p class="text-slate-600 text-lg leading-relaxed">To empower businesses with seamless, technology-driven logistics solutions that reduce costs, save time, and create exceptional customer experiences.</p>
      </div>
      <div class="bg-white rounded-2xl p-8 border border-slate-200 shadow-sm h-full">
        <div class="w-14 h-14 rounded-2xl bg-purple-100 flex items-center justify-center mb-6 text-2xl">👁️</div>
        <h3 class="text-2xl font-bold text-slate-900 mb-4">Our Vision</h3>
        <p class="text-slate-600 text-lg leading-relaxed">To become the most trusted logistics partner for businesses worldwide, setting new standards for reliability, innovation, and customer satisfaction.</p>
      </div>
    </div>
  </div>
</section>

<!-- Values -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">Our Values</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">These core principles guide everything we do.</p>
    </div>
    <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
      <?php foreach ([['🎯','Customer First','Every decision starts with our customers\' needs.'],['🚀','Innovation','We constantly push boundaries.'],['❤️','Reliability','Trust is earned through consistent performance.'],['👥','Collaboration','We believe in partnerships and teamwork.']] as $v): ?>
      <div class="text-center">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-100 to-purple-100 mb-6 text-3xl"><?php echo $v[0]; ?></div>
        <h3 class="text-xl font-bold text-slate-900 mb-3"><?php echo esc_html($v[1]); ?></h3>
        <p class="text-slate-600"><?php echo esc_html($v[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Team -->
<section class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">Meet Our Team</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">The passionate people behind Aruna Logistics Solution's success.</p>
    </div>
    <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
      <?php foreach ([['Alex Johnson','CEO & Co-Founder'],['Sarah Chen','COO'],['Michael Williams','CTO'],['Priya Patel','VP of Operations'],['David Kim','VP of Sales'],['Emily Brown','VP of Marketing']] as $m): ?>
      <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm text-center hover:shadow-lg transition-shadow">
        <div class="w-24 h-24 rounded-full bg-gradient-to-br from-orange-400 to-purple-500 mx-auto mb-4 flex items-center justify-center text-white text-3xl font-bold"><?php echo esc_html($m[0][0]); ?></div>
        <h3 class="text-xl font-bold text-slate-900 mb-1"><?php echo esc_html($m[0]); ?></h3>
        <p class="text-slate-500"><?php echo esc_html($m[1]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Journey -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl font-bold text-slate-900 mb-4">Our Journey</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">Key milestones that shaped Aruna Logistics Solution.</p>
    </div>
    <div class="max-w-3xl mx-auto space-y-8">
      <?php foreach ([['2018','Company Founded','Aruna Logistics Solution was born.'],['2019','First 100 Clients','Reached our first major milestone.'],['2021','1 Million Shipments','Crossed 1 million successful deliveries.'],['2023','Industry Recognition','Named "Best Logistics Platform".'],['2025','500+ Brand Partners','Growing family of over 500 trusted partners.']] as $ml): ?>
      <div class="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
        <span class="inline-block px-3 py-1 bg-orange-100 text-orange-600 rounded-full text-sm font-semibold mb-3"><?php echo esc_html($ml[0]); ?></span>
        <h3 class="text-xl font-bold text-slate-900 mb-2"><?php echo esc_html($ml[1]); ?></h3>
        <p class="text-slate-600"><?php echo esc_html($ml[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php get_footer(); ?>
