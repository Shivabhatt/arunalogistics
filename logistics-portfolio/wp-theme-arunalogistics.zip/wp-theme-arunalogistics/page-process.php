<?php
/**
 * Template Name: Process Page
 */
get_header();
?>

<!-- Hero -->
<section class="relative pt-32 pb-20 bg-gradient-to-br from-slate-900 via-slate-900 to-orange-900 overflow-hidden">
  <div class="absolute inset-0 opacity-10"><svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="prGrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(#prGrid)"/></svg></div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center max-w-4xl mx-auto">
    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">How <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-200">Aruna Logistics Works</span></h1>
    <p class="text-xl text-slate-300 mb-8">From order creation to final delivery, our streamlined process ensures your shipments are handled with care.</p>
  </div>
</section>

<!-- Steps -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Simple 6-Step Process</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">Our efficient workflow ensures smooth operations from start to finish.</p>
    </div>
    <div class="max-w-4xl mx-auto space-y-16">
      <?php
      $steps = [
        ['01','📤','Ship Your Order','Create your shipment through our platform, app, or API.',['Multiple integration options','Bulk upload available','Auto-fill with past orders','Real-time rate comparison']],
        ['02','⚙️','Automatic Processing','Our AI-powered system processes your order and selects optimal routes.',['Smart route optimization','Automated label generation','Warehouse allocation','Quality checks']],
        ['03','📦','Pickup & Packaging','Schedule a pickup or drop off at our fulfillment centers.',['Flexible pickup schedules','Professional packaging','Security scanning','Weight verification']],
        ['04','🚚','In-Transit Tracking','Track your shipment in real-time through our network.',['Live GPS tracking','Milestone notifications','ETA updates','Exception alerts']],
        ['05','📍','Last-Mile Delivery','Our delivery partners ensure safe last-mile delivery.',['Photo proof of delivery','Digital signature','Customer communication','Safe drop-off options']],
        ['06','✅','Delivery Confirmation','Receive instant confirmation with proof of delivery.',['Instant confirmation','POD with photo','Customer feedback','Performance analytics']],
      ];
      foreach ($steps as $step): ?>
      <div class="grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div class="flex items-center gap-4 mb-4">
            <span class="text-6xl font-bold text-orange-100"><?php echo esc_html($step[0]); ?></span>
            <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 to-purple-600 flex items-center justify-center text-3xl"><?php echo $step[1]; ?></div>
          </div>
          <h3 class="text-2xl font-bold text-slate-900 mb-3"><?php echo esc_html($step[2]); ?></h3>
          <p class="text-slate-600 mb-6 text-lg"><?php echo esc_html($step[3]); ?></p>
          <div class="space-y-2">
            <?php foreach ($step[4] as $d): ?>
            <div class="flex items-center gap-2"><span class="text-green-500">✓</span><span class="text-slate-600"><?php echo esc_html($d); ?></span></div>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl border-2 border-orange-200 p-6">
          <div class="h-48 flex items-center justify-center text-8xl opacity-30"><?php echo $step[1]; ?></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Why choose our process -->
<section class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Why Choose Our Process?</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">Technology-driven efficiency meets human expertise.</p>
    </div>
    <div class="grid md:grid-cols-3 gap-8">
      <?php foreach ([['📊','Real-Time Analytics','Monitor your logistics performance with detailed dashboards.'],['🎧','24/7 Support','Get assistance anytime with our dedicated support team.'],['⚙️','API Integration','Seamlessly integrate with your existing systems.']] as $feat): ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 text-center hover:shadow-lg transition-all duration-300">
        <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-100 to-purple-100 mb-6 text-3xl"><?php echo $feat[0]; ?></div>
        <h3 class="text-xl font-bold text-slate-900 mb-3"><?php echo esc_html($feat[1]); ?></h3>
        <p class="text-slate-600"><?php echo esc_html($feat[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- CTA -->
<section class="py-20 bg-gradient-to-br from-slate-900 via-slate-900 to-purple-900">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
    <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">Experience the Difference</h2>
    <p class="text-xl mb-8 max-w-2xl mx-auto text-slate-300">Join 500+ businesses that trust Aruna Logistics Solution.</p>
    <div class="flex flex-col sm:flex-row gap-4 justify-center">
      <a href="<?php echo esc_url( home_url('/quote') ); ?>" class="inline-flex items-center justify-center font-semibold rounded-lg bg-orange-500 text-white hover:bg-orange-600 shadow-lg px-8 py-4 text-lg transition-all duration-300">Get Started Now</a>
      <a href="<?php echo esc_url( home_url('/contact') ); ?>" class="inline-flex items-center justify-center font-semibold rounded-lg border-2 border-white text-white hover:bg-white/10 px-8 py-4 text-lg transition-all duration-300">Talk to an Expert</a>
    </div>
  </div>
</section>

<?php get_footer(); ?>
