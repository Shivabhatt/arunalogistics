<?php
/**
 * Front Page template – full conversion of Next.js home page sections.
 */
get_header();
?>

<!-- ===== HERO ===== -->
<section class="relative min-h-screen flex items-center bg-gradient-to-br from-slate-900 via-slate-900 to-purple-900 overflow-hidden">
  <div class="absolute inset-0 opacity-10">
    <svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs><pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="1"/></pattern></defs>
      <rect width="100%" height="100%" fill="url(#grid)"/>
    </svg>
  </div>
  <div class="absolute top-20 left-10 w-72 h-72 bg-purple-500 rounded-full filter blur-[128px] opacity-30 animate-pulse"></div>
  <div class="absolute bottom-20 right-10 w-96 h-96 bg-orange-500 rounded-full filter blur-[128px] opacity-20 animate-pulse"></div>

  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-20">
    <div class="grid lg:grid-cols-2 gap-12 items-center">
      <div>
        <div class="mb-4">
          <span class="inline-block px-4 py-2 bg-orange-500/10 border border-orange-500/20 rounded-full text-orange-400 text-sm font-semibold mb-6">🚀 India's Most Trusted Logistics Partner</span>
        </div>
        <h1 class="text-4xl sm:text-5xl lg:text-7xl font-bold text-white leading-tight mb-6">
          Smart Logistics. <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">Seamless Delivery.</span>
        </h1>
        <p class="text-lg sm:text-xl text-slate-300 mb-6 max-w-xl">
          Transform your supply chain with <span class="font-semibold text-white">Aruna Logistics Solution</span>.
          Delivering excellence across 200+ cities with cutting-edge technology and unmatched reliability.
        </p>
        <div class="flex flex-wrap gap-4 mb-8">
          <?php foreach (['99.5% On-Time Delivery','Pan-India Coverage','24/7 Customer Support','Best-in-Class Pricing'] as $prop): ?>
          <div class="flex items-center gap-2 bg-slate-800/50 backdrop-blur-sm px-4 py-2 rounded-lg border border-slate-700">
            <div class="w-2 h-2 rounded-full bg-green-400"></div>
            <span class="text-sm text-slate-200"><?php echo esc_html($prop); ?></span>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="flex flex-col sm:flex-row gap-4 mb-12">
          <a href="#services" class="inline-flex items-center justify-center font-semibold rounded-lg bg-orange-500 text-white hover:bg-orange-600 shadow-lg hover:shadow-xl px-8 py-4 text-lg transition-all duration-300">Explore Our Services &rarr;</a>
          <a href="#contact" class="inline-flex items-center justify-center font-semibold rounded-lg border-2 border-white text-white hover:bg-white/10 backdrop-blur-sm px-8 py-4 text-lg transition-all duration-300">Contact Us</a>
        </div>
        <div class="flex flex-wrap gap-6">
          <div class="flex items-center gap-2 text-slate-300"><span class="text-sm font-medium">👥 500+ Brand Partners</span></div>
          <div class="flex items-center gap-2 text-slate-300"><span class="text-sm font-medium">📍 200+ Cities Covered</span></div>
          <div class="flex items-center gap-2 text-slate-300"><span class="text-sm font-medium">⭐ 4.9★ Customer Rating</span></div>
        </div>
      </div>

      <!-- service mini-cards (desktop) -->
      <div class="relative hidden lg:block">
        <div class="grid grid-cols-2 gap-4">
          <?php
          $hero_services = [
            ['🚚','Express Delivery','Same & next-day delivery'],
            ['📦','Warehousing','Smart storage solutions'],
            ['🌐','International','Global shipping network'],
            ['🛡️','Secure Handling','Insured & safe transit'],
          ];
          foreach ($hero_services as $s): ?>
          <div class="bg-slate-800/60 backdrop-blur-sm rounded-2xl border border-slate-700 p-6 hover:border-orange-500/50 transition-all duration-300">
            <div class="w-12 h-12 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center mb-4 text-2xl"><?php echo $s[0]; ?></div>
            <h3 class="text-white font-semibold text-lg mb-1"><?php echo esc_html($s[1]); ?></h3>
            <p class="text-slate-400 text-sm"><?php echo esc_html($s[2]); ?></p>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="mt-4 bg-gradient-to-r from-orange-500 to-purple-600 rounded-2xl p-5">
          <div class="grid grid-cols-3 gap-4 text-center text-white">
            <div><span class="text-2xl font-bold">10M+</span><p class="text-xs opacity-90">Shipments Delivered</p></div>
            <div><span class="text-2xl font-bold">99.5%</span><p class="text-xs opacity-90">On-Time Rate</p></div>
            <div><span class="text-2xl font-bold">200+</span><p class="text-xs opacity-90">Cities Covered</p></div>
          </div>
        </div>
        <div class="absolute -top-4 -right-4 bg-green-500 text-white rounded-xl px-4 py-3 shadow-lg shadow-green-500/25">
          <p class="text-sm font-bold">✓ ISO Certified</p>
          <p class="text-xs opacity-80">Quality Assured</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ===== PARTNERS ===== -->
<section class="py-16 bg-white border-b border-slate-100">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <p class="text-center text-slate-500 mb-8 text-sm font-medium uppercase tracking-wider">Trusted by Leading Brands</p>
    <div class="relative overflow-hidden">
      <div class="flex animate-scroll">
        <?php
        $partners = ['TechStyle','GreenBox','FreshMart','StyleHub','ElectroMart','HomeGoods','FashionFirst','BeautyBox','SportZone','BookWorld'];
        for ($i = 0; $i < 2; $i++):
          foreach ($partners as $p): ?>
            <div class="flex-shrink-0 mx-8">
              <div class="w-32 h-12 bg-slate-100 rounded-lg flex items-center justify-center grayscale hover:grayscale-0 transition-all duration-300 hover:bg-slate-200">
                <span class="text-slate-600 font-semibold"><?php echo esc_html($p); ?></span>
              </div>
            </div>
          <?php endforeach;
        endfor; ?>
      </div>
    </div>
  </div>
</section>

<!-- ===== STATS ===== -->
<section class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-8">
      <?php
      $stats = [
        ['📦','1M+','Shipments Delivered'],
        ['👥','500+','Brand Partners'],
        ['📍','200+','Cities Covered'],
        ['⏱️','99.5%','On-Time Delivery'],
      ];
      foreach ($stats as $st): ?>
      <div class="text-center">
        <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-orange-100 text-orange-500 mb-4 text-2xl"><?php echo $st[0]; ?></div>
        <div class="text-4xl lg:text-5xl font-bold text-slate-900 mb-2"><?php echo esc_html($st[1]); ?></div>
        <p class="text-slate-600 font-medium"><?php echo esc_html($st[2]); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ===== SERVICES ===== -->
<section id="services" class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Our Services</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">Comprehensive logistics solutions tailored to your business needs.</p>
    </div>
    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
      <?php
      $services = [
        ['🚚','Express Parcel','Same-day and next-day delivery services nationwide. Fast, reliable, and cost-effective shipping for all your urgent needs.'],
        ['📦','Freight Services','Part Truckload (PTL) and Full Truckload (FTL) solutions for bulk shipments. Optimized routes for maximum efficiency.'],
        ['🏭','Warehousing','State-of-the-art storage and fulfillment centers strategically located. Inventory management and order processing.'],
        ['🌐','International Shipping','Ship to 220+ countries with our global network. Customs clearance, documentation, and door-to-door delivery.'],
        ['📍','Real-Time Tracking','End-to-end shipment visibility with live tracking. Automated notifications and delivery updates.'],
        ['🔄','Returns Management','Hassle-free reverse logistics with easy return pickups. Streamlined processing and refund management.'],
      ];
      foreach ($services as $svc): ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
        <div class="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-100 to-orange-50 text-orange-500 mb-6 text-2xl"><?php echo $svc[0]; ?></div>
        <h3 class="text-xl font-bold text-slate-900 mb-3"><?php echo esc_html($svc[1]); ?></h3>
        <p class="text-slate-600 leading-relaxed"><?php echo esc_html($svc[2]); ?></p>
        <a href="#contact" class="inline-flex items-center mt-4 text-orange-500 font-medium hover:text-orange-600 transition-colors">Learn more &rarr;</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ===== WHY US ===== -->
<section class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid lg:grid-cols-2 gap-16 items-center">
      <div>
        <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
          Why Choose <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-purple-600">Aruna Logistics?</span>
        </h2>
        <p class="text-lg text-slate-600 mb-10">We combine cutting-edge technology with extensive logistics expertise.</p>
        <div class="space-y-6">
          <?php
          $features = [
            ['🚚','50+ Courier Partners','Access the best rates across multiple carriers.'],
            ['🌐','AI-Powered Route Optimization','Smart algorithms find the fastest routes.'],
            ['🎧','24/7 Dedicated Support','Round-the-clock assistance for all queries.'],
            ['💻','Simple API Integration','Connect your systems in minutes.'],
            ['📉','Reduce RTO by 40%','Advanced analytics to minimize returns.'],
          ];
          foreach ($features as $f): ?>
          <div class="flex gap-4">
            <div class="flex-shrink-0"><div class="w-12 h-12 rounded-xl bg-orange-100 flex items-center justify-center text-xl"><?php echo $f[0]; ?></div></div>
            <div>
              <h3 class="text-lg font-semibold text-slate-900 mb-1"><?php echo esc_html($f[1]); ?></h3>
              <p class="text-slate-600"><?php echo esc_html($f[2]); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="relative">
        <div class="bg-white rounded-2xl shadow-xl p-8 border border-slate-100">
          <div class="flex items-center gap-4 mb-8">
            <div class="w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-500 to-purple-600 flex items-center justify-center text-3xl">🌐</div>
            <div><h3 class="text-xl font-bold text-slate-900">Global Network</h3><p class="text-slate-500">Connected worldwide</p></div>
          </div>
          <div class="grid grid-cols-3 gap-4 mt-6">
            <div class="text-center"><p class="text-2xl font-bold text-slate-900">220+</p><p class="text-sm text-slate-500">Countries</p></div>
            <div class="text-center"><p class="text-2xl font-bold text-slate-900">50+</p><p class="text-sm text-slate-500">Carriers</p></div>
            <div class="text-center"><p class="text-2xl font-bold text-slate-900">99.5%</p><p class="text-sm text-slate-500">Uptime</p></div>
          </div>
        </div>
        <div class="absolute -top-4 -right-4 bg-green-500 text-white rounded-xl px-4 py-2 shadow-lg">
          <div class="flex items-center gap-2"><span class="font-medium">✓ Enterprise Ready</span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ===== TESTIMONIALS ===== -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">What Our Clients Say</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">Don't just take our word for it.</p>
    </div>
    <div class="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
      <?php
      $testimonials = [
        ['Aruna Logistics Solution has transformed our delivery operations. We\'ve seen a 40% reduction in shipping costs.','Sarah Johnson','Operations Director','TechStyle Fashion'],
        ['The integration was seamless and their support team is incredibly responsive. Delivery success rate improved from 85% to 98%.','Michael Chen','CEO','GreenBox Electronics'],
        ['We\'ve been using Aruna Logistics for our international shipments and the experience has been exceptional.','Priya Sharma','Supply Chain Manager','Artisan Crafts Co.'],
        ['The warehousing solutions helped us scale our business 3x without worrying about logistics.','David Williams','Founder','FreshMart Groceries'],
      ];
      foreach ($testimonials as $t): ?>
      <div class="bg-white rounded-2xl border border-slate-200 shadow-lg p-8">
        <div class="text-orange-200 text-4xl mb-4">&ldquo;</div>
        <p class="text-lg text-slate-700 leading-relaxed mb-6"><?php echo esc_html($t[0]); ?></p>
        <div class="flex items-center gap-4">
          <div class="w-12 h-12 rounded-full bg-gradient-to-br from-orange-400 to-purple-500 flex items-center justify-center text-white font-bold text-lg"><?php echo esc_html($t[1][0]); ?></div>
          <div>
            <p class="font-semibold text-slate-900"><?php echo esc_html($t[1]); ?></p>
            <p class="text-slate-500"><?php echo esc_html($t[2]) . ', ' . esc_html($t[3]); ?></p>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ===== CASE STUDIES ===== -->
<section class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Success Stories</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">See how businesses achieved remarkable results with Aruna Logistics.</p>
    </div>
    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
      <?php
      $cases = [
        ['TechStyle Fashion','80% Faster Processing','Managing high-volume fashion deliveries during peak seasons.','Reduced order-to-dispatch time from 4 hours to 45 minutes.'],
        ['GreenBox Electronics','50% RTO Reduction','Reducing return-to-origin rates and improving first-attempt deliveries.','Improved delivery success rate from 82% to 96%.'],
        ['FreshMart Groceries','40% Cost Savings','Scaling from 100 to 5,000 daily orders while maintaining quality.','Optimized shipping costs through smart courier allocation.'],
      ];
      foreach ($cases as $c): ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
        <div class="h-16 bg-slate-100 rounded-lg flex items-center justify-center mb-6">
          <span class="text-xl font-bold text-slate-400"><?php echo esc_html($c[0]); ?></span>
        </div>
        <div class="inline-flex px-4 py-2 bg-gradient-to-r from-orange-500 to-purple-600 text-white rounded-full text-sm font-semibold mb-4"><?php echo esc_html($c[1]); ?></div>
        <p class="text-slate-600 mb-4"><?php echo esc_html($c[2]); ?></p>
        <p class="text-sm text-slate-500 mb-4"><?php echo esc_html($c[3]); ?></p>
        <a href="#contact" class="inline-flex items-center text-orange-500 font-medium hover:text-orange-600 transition-colors">Read Case Study &nearr;</a>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ===== FINAL CTA ===== -->
<section class="relative py-24 bg-gradient-to-br from-slate-900 via-slate-900 to-purple-900 overflow-hidden">
  <div class="absolute inset-0 opacity-10">
    <svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="ctaGrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(#ctaGrid)"/></svg>
  </div>
  <div class="absolute top-0 left-1/4 w-64 h-64 bg-purple-500 rounded-full filter blur-[128px] opacity-30"></div>
  <div class="absolute bottom-0 right-1/4 w-64 h-64 bg-orange-500 rounded-full filter blur-[128px] opacity-20"></div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
    <div class="text-center max-w-3xl mx-auto">
      <div class="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full text-orange-300 text-sm font-medium mb-6">✨ Ready to Get Started?</div>
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
        Ready to Transform <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-purple-400">Your Logistics?</span>
      </h2>
      <p class="text-lg text-slate-300 mb-10 max-w-2xl mx-auto">Partner with us to scale your shipping operations. Join 500+ brands that trust Aruna Logistics Solution.</p>
      <div class="flex flex-col sm:flex-row gap-4 justify-center">
        <a href="#contact" class="inline-flex items-center justify-center font-semibold rounded-lg bg-orange-500 text-white hover:bg-orange-600 shadow-lg hover:shadow-xl px-8 py-4 text-lg transition-all duration-300">Contact Us Today &rarr;</a>
      </div>
      <div class="flex flex-wrap justify-center gap-8 mt-12 text-slate-400">
        <div class="flex items-center gap-2"><span class="text-green-400">✓</span><span class="text-sm">No Hidden Fees</span></div>
        <div class="flex items-center gap-2"><span class="text-green-400">✓</span><span class="text-sm">24/7 Support</span></div>
        <div class="flex items-center gap-2"><span class="text-green-400">✓</span><span class="text-sm">Easy Integration</span></div>
      </div>
    </div>
  </div>
</section>

<!-- ===== CONTACT ===== -->
<section id="contact" class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Get in Touch</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">Have questions? Reach out and our team will get back to you shortly.</p>
    </div>
    <div class="grid lg:grid-cols-2 gap-12 lg:gap-16">
      <div class="bg-white rounded-2xl border border-slate-200 shadow-lg p-8">
        <h3 class="text-2xl font-bold text-slate-900 mb-6">Send us a Message</h3>
        <form class="space-y-6" method="post">
          <div class="grid sm:grid-cols-2 gap-6">
            <div><label class="block text-sm font-medium text-slate-700 mb-2">Full Name</label><input type="text" placeholder="John Doe" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
            <div><label class="block text-sm font-medium text-slate-700 mb-2">Email</label><input type="email" placeholder="john@company.com" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
          </div>
          <div class="grid sm:grid-cols-2 gap-6">
            <div><label class="block text-sm font-medium text-slate-700 mb-2">Company</label><input type="text" placeholder="Your Company" class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
            <div><label class="block text-sm font-medium text-slate-700 mb-2">Phone</label><input type="tel" placeholder="+1 (555) 000-0000" class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
          </div>
          <div><label class="block text-sm font-medium text-slate-700 mb-2">Message</label><textarea placeholder="Tell us about your shipping needs..." rows="5" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"></textarea></div>
          <button type="submit" class="w-full inline-flex items-center justify-center font-semibold rounded-lg bg-orange-500 text-white hover:bg-orange-600 shadow-lg hover:shadow-xl px-8 py-4 text-lg transition-all duration-300">Send Message ✉️</button>
        </form>
      </div>
      <div class="flex flex-col justify-center h-full">
        <div class="space-y-8">
          <?php
          $contact_info = [
            ['✉️','Email Us','hello@arunalogistics.com','We reply within 24 hours'],
            ['📞','Call Us','+1 (555) 123-4567','Mon-Fri, 9am-6pm EST'],
            ['📍','Visit Us','123 Logistics Way','Shipping City, SC 12345'],
          ];
          foreach ($contact_info as $ci): ?>
          <div class="flex gap-5 p-6 bg-slate-50 rounded-xl hover:bg-orange-50 transition-colors">
            <div class="flex-shrink-0"><div class="w-14 h-14 rounded-xl bg-orange-100 flex items-center justify-center text-2xl"><?php echo $ci[0]; ?></div></div>
            <div>
              <h4 class="text-lg font-semibold text-slate-900 mb-1"><?php echo esc_html($ci[1]); ?></h4>
              <p class="text-slate-700 font-medium"><?php echo esc_html($ci[2]); ?></p>
              <p class="text-sm text-slate-500"><?php echo esc_html($ci[3]); ?></p>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
