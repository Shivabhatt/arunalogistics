<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Google Fonts – Inter -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <!-- Tailwind CSS CDN (Play CDN) -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: { sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'] },
        }
      }
    }
  </script>
  <?php wp_head(); ?>
</head>
<body <?php body_class( 'font-sans antialiased' ); ?>>
  <a href="#main-content" class="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-orange-500 text-white px-4 py-2 rounded-lg z-[100]">Skip to main content</a>

  <!-- Fixed Header -->
  <header id="site-header" class="fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-white/80 backdrop-blur-md border-b border-slate-200/50 shadow-sm">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div class="flex items-center justify-between h-16 lg:h-20">
        <!-- Logo -->
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="flex items-center space-x-2 group">
          <div class="w-10 h-10 bg-gradient-to-br from-orange-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-orange-500/25 transition-shadow duration-300">
            <span class="text-white font-bold text-xl">A</span>
          </div>
          <div class="flex flex-col">
            <span class="text-lg font-bold text-slate-900 leading-tight">Aruna</span>
            <span class="text-xs text-slate-500 -mt-0.5 tracking-wider uppercase">Logistics</span>
          </div>
        </a>

        <!-- Desktop Navigation -->
        <nav class="hidden lg:flex items-center space-x-1" role="navigation" aria-label="Primary Menu">
          <?php
          $nav_links = [
            ['/', 'Home'],
            ['/about', 'About'],
            ['/services', 'Services'],
            ['/process', 'Process'],
            ['/pricing', 'Pricing'],
            ['/blog', 'Blog'],
            ['/contact', 'Contact'],
          ];
          foreach ($nav_links as $link):
            $is_active = (trim($_SERVER['REQUEST_URI'], '/') === trim($link[0], '/')) || ($link[0] === '/' && $_SERVER['REQUEST_URI'] === '/');
          ?>
            <a href="<?php echo esc_url(home_url($link[0])); ?>"
               class="relative px-4 py-2 text-sm font-medium rounded-lg transition-all duration-200 <?php echo $is_active ? 'text-orange-600 bg-orange-50' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'; ?>">
              <?php echo esc_html($link[1]); ?>
            </a>
          <?php endforeach; ?>
        </nav>

        <!-- Desktop CTA -->
        <div class="hidden lg:flex items-center space-x-3">
          <a href="<?php echo esc_url(home_url('/quote')); ?>" class="inline-flex items-center justify-center px-6 py-2.5 text-sm font-semibold rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-600 hover:to-orange-700 shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 transition-all duration-300">
            Get a Quote
          </a>
        </div>

        <!-- Mobile Menu Toggle -->
        <button id="mobile-menu-btn" class="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100 transition-colors" aria-expanded="false" aria-label="Toggle navigation menu">
          <svg id="menu-icon-open" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/></svg>
          <svg id="menu-icon-close" class="w-6 h-6 hidden" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>
        </button>
      </div>
    </div>

    <!-- Mobile Menu Panel -->
    <div id="mobile-menu" class="lg:hidden hidden bg-white/95 backdrop-blur-lg border-t border-slate-200/50">
      <div class="max-w-7xl mx-auto px-4 py-4 space-y-1">
        <?php foreach ($nav_links as $link):
          $is_active = (trim($_SERVER['REQUEST_URI'], '/') === trim($link[0], '/')) || ($link[0] === '/' && $_SERVER['REQUEST_URI'] === '/');
        ?>
          <a href="<?php echo esc_url(home_url($link[0])); ?>"
             class="block px-4 py-3 text-base font-medium rounded-xl transition-all duration-200 <?php echo $is_active ? 'text-orange-600 bg-orange-50' : 'text-slate-700 hover:text-slate-900 hover:bg-slate-50'; ?>">
            <?php echo esc_html($link[1]); ?>
          </a>
        <?php endforeach; ?>
        <div class="pt-4 border-t border-slate-200 mt-2">
          <a href="<?php echo esc_url(home_url('/quote')); ?>" class="block w-full text-center px-6 py-3 text-base font-semibold rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 text-white hover:from-orange-600 hover:to-orange-700 shadow-lg transition-all duration-300">
            Get a Quote
          </a>
        </div>
      </div>
    </div>
  </header>

  <main id="main-content">
