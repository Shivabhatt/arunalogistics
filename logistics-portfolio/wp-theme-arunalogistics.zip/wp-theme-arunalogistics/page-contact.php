<?php
/**
 * Template Name: Contact Page
 */
get_header();
?>

<!-- Hero -->
<section class="relative pt-32 pb-20 bg-gradient-to-br from-slate-900 via-slate-900 to-orange-900 overflow-hidden">
  <div class="absolute inset-0 opacity-10"><svg class="w-full h-full" xmlns="http://www.w3.org/2000/svg"><defs><pattern id="cGrid" width="40" height="40" patternUnits="userSpaceOnUse"><path d="M 40 0 L 0 0 0 40" fill="none" stroke="white" stroke-width="1"/></pattern></defs><rect width="100%" height="100%" fill="url(#cGrid)"/></svg></div>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center max-w-4xl mx-auto">
    <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">Get in <span class="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-200">Touch</span></h1>
    <p class="text-xl text-slate-300">Have questions about our services? Our team is here to help you 24/7.</p>
  </div>
</section>

<!-- Contact Methods -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="grid md:grid-cols-3 gap-8 mb-20">
      <?php
      $methods = [
        ['✉️','Email Us',['hello@arunalogistics.com','support@arunalogistics.com'],'We reply within 2 hours','mailto:hello@arunalogistics.com'],
        ['📞','Call Us',['+1 (555) 123-4567','+1 (555) 765-4321'],'Mon-Fri, 9am-6pm EST','tel:+15551234567'],
        ['📍','Visit Us',['123 Logistics Way','Shipping City, SC 12345'],'Main Office','#'],
      ];
      foreach ($methods as $m): ?>
      <a href="<?php echo esc_url($m[4]); ?>" class="block">
        <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 text-center h-full hover:shadow-xl transition-all duration-300 group">
          <div class="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-orange-100 to-orange-50 mb-6 text-3xl group-hover:from-orange-500 group-hover:to-purple-600 transition-all duration-300"><?php echo $m[0]; ?></div>
          <h3 class="text-xl font-bold text-slate-900 mb-3"><?php echo esc_html($m[1]); ?></h3>
          <?php foreach ($m[2] as $line): ?>
          <p class="text-slate-700 font-medium mb-1"><?php echo esc_html($line); ?></p>
          <?php endforeach; ?>
          <p class="text-sm text-slate-500 mt-3"><?php echo esc_html($m[3]); ?></p>
        </div>
      </a>
      <?php endforeach; ?>
    </div>

    <!-- Form + Support -->
    <div class="grid lg:grid-cols-2 gap-12">
      <div>
        <h2 class="text-3xl font-bold text-slate-900 mb-6">Send us a Message</h2>
        <form class="space-y-6" method="post">
          <div class="grid sm:grid-cols-2 gap-6">
            <div><label class="block text-sm font-medium text-slate-700 mb-2">Full Name</label><input type="text" placeholder="John Doe" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
            <div><label class="block text-sm font-medium text-slate-700 mb-2">Email</label><input type="email" placeholder="john@company.com" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
          </div>
          <div class="grid sm:grid-cols-2 gap-6">
            <div><label class="block text-sm font-medium text-slate-700 mb-2">Company</label><input type="text" placeholder="Your Company" class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
            <div><label class="block text-sm font-medium text-slate-700 mb-2">Phone</label><input type="tel" placeholder="+1 (555) 000-0000" class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
          </div>
          <div><label class="block text-sm font-medium text-slate-700 mb-2">Subject</label><input type="text" placeholder="How can we help you?" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"></div>
          <div><label class="block text-sm font-medium text-slate-700 mb-2">Message</label><textarea placeholder="Tell us about your logistics needs..." rows="6" required class="w-full px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"></textarea></div>
          <button type="submit" class="w-full inline-flex items-center justify-center font-semibold rounded-lg bg-orange-500 text-white hover:bg-orange-600 shadow-lg px-8 py-4 text-lg transition-all duration-300">Send Message ✉️</button>
        </form>
      </div>
      <div>
        <h2 class="text-3xl font-bold text-slate-900 mb-6">Support Options</h2>
        <div class="space-y-6">
          <?php foreach ([['🎧','24/7 Customer Support','Get immediate assistance','Available 24/7'],['💬','Live Chat','Chat with our representatives in real-time','Response in 2-5 minutes'],['⏰','Scheduled Consultation','Book a meeting with our logistics experts','Book your slot']] as $so): ?>
          <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6 hover:shadow-lg transition-all duration-300">
            <div class="flex gap-4">
              <div class="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-purple-100 to-purple-50 flex items-center justify-center text-xl"><?php echo $so[0]; ?></div>
              <div>
                <h3 class="text-lg font-bold text-slate-900 mb-1"><?php echo esc_html($so[1]); ?></h3>
                <p class="text-slate-600 mb-2"><?php echo esc_html($so[2]); ?></p>
                <span class="text-sm text-green-600 font-medium"><?php echo esc_html($so[3]); ?></span>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Offices -->
<section class="py-20 bg-slate-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-16">
      <h2 class="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 mb-4">Our Locations</h2>
      <p class="text-lg text-slate-600 max-w-2xl mx-auto">Visit our offices and logistics facilities.</p>
    </div>
    <div class="grid md:grid-cols-3 gap-8">
      <?php foreach ([['Los Angeles Hub','456 Harbor Blvd, Los Angeles, CA 90012','+1 (555) 111-2222','24/7 Operations'],['New York Office','789 Trade Center, New York, NY 10001','+1 (555) 333-4444','Mon-Fri: 8am-8pm EST'],['Chicago Facility','321 Freight Ave, Chicago, IL 60601','+1 (555) 555-6666','24/7 Operations']] as $o): ?>
      <div class="bg-white rounded-xl border border-slate-200 shadow-sm p-6">
        <h3 class="text-xl font-bold text-slate-900 mb-4"><?php echo esc_html($o[0]); ?></h3>
        <div class="space-y-3">
          <div class="flex items-start gap-3 text-slate-600"><span class="text-orange-500">📍</span><span><?php echo esc_html($o[1]); ?></span></div>
          <div class="flex items-center gap-3 text-slate-600"><span class="text-orange-500">📞</span><span><?php echo esc_html($o[2]); ?></span></div>
          <div class="flex items-center gap-3 text-slate-600"><span class="text-orange-500">⏰</span><span><?php echo esc_html($o[3]); ?></span></div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- Map Placeholder -->
<section class="py-20 bg-white">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <div class="rounded-2xl overflow-hidden border border-slate-200 shadow-lg">
      <div class="h-96 bg-slate-100 flex items-center justify-center">
        <div class="text-center"><span class="text-5xl">📍</span><p class="text-slate-400 text-lg mt-4">Interactive Map Integration Available</p><p class="text-slate-500 text-sm mt-2">Google Maps / Mapbox Ready</p></div>
      </div>
    </div>
  </div>
</section>

<?php get_footer(); ?>
