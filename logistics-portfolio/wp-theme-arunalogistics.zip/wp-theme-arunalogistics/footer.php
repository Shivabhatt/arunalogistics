  </main>
  <footer class="bg-slate-900 text-white" role="contentinfo">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
      <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
        <!-- Brand -->
        <div class="lg:col-span-1">
          <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="flex items-center space-x-2 mb-4">
            <div class="w-10 h-10 bg-gradient-to-br from-orange-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <span class="text-white font-bold text-xl">A</span>
            </div>
            <div class="flex flex-col">
              <span class="text-lg font-bold text-white leading-tight">Aruna</span>
              <span class="text-xs text-slate-400 -mt-0.5 tracking-wider uppercase">Logistics</span>
            </div>
          </a>
          <p class="text-slate-400 mb-6">Your trusted partner for end-to-end logistics excellence across India and beyond.</p>
          <div class="flex space-x-3">
            <a href="#" class="w-10 h-10 bg-slate-800 hover:bg-orange-500 rounded-lg flex items-center justify-center transition-colors duration-300" aria-label="Twitter"><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M22.46 6c-.77.35-1.6.58-2.46.69a4.3 4.3 0 001.88-2.38 8.59 8.59 0 01-2.72 1.04 4.28 4.28 0 00-7.32 3.91A12.16 12.16 0 013.15 4.83a4.28 4.28 0 001.33 5.72 4.24 4.24 0 01-1.94-.54v.05a4.28 4.28 0 003.44 4.2 4.27 4.27 0 01-1.93.07 4.29 4.29 0 004 2.98A8.59 8.59 0 012 19.54a12.13 12.13 0 006.56 1.92c7.88 0 12.2-6.53 12.2-12.2l-.01-.56A8.7 8.7 0 0024 5.06a8.5 8.5 0 01-2.54.7z"/></svg></a>
            <a href="#" class="w-10 h-10 bg-slate-800 hover:bg-orange-500 rounded-lg flex items-center justify-center transition-colors duration-300" aria-label="LinkedIn"><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.13 1.45-2.13 2.94v5.67H9.35V9h3.41v1.56h.05c.48-.9 1.64-1.85 3.37-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28zM5.34 7.43a2.07 2.07 0 110-4.13 2.07 2.07 0 010 4.13zM6.91 20.45H3.34V9h3.57v11.45zM22.23 0H1.77C.79 0 0 .77 0 1.72v20.56C0 23.23.79 24 1.77 24h20.46c.98 0 1.77-.77 1.77-1.72V1.72C24 .77 23.21 0 22.23 0z"/></svg></a>
            <a href="#" class="w-10 h-10 bg-slate-800 hover:bg-orange-500 rounded-lg flex items-center justify-center transition-colors duration-300" aria-label="Facebook"><svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.07C24 5.41 18.63 0 12 0S0 5.41 0 12.07c0 6.02 4.39 11.01 10.13 11.93v-8.44H7.08v-3.49h3.05V9.41c0-3.02 1.8-4.69 4.54-4.69 1.31 0 2.68.23 2.68.23v2.97h-1.51c-1.49 0-1.96.93-1.96 1.88v2.27h3.34l-.53 3.49h-2.81v8.44C19.61 23.08 24 18.09 24 12.07z"/></svg></a>
          </div>
        </div>
        <!-- Company -->
        <div>
          <h4 class="text-sm font-semibold text-white uppercase tracking-wider mb-4">Company</h4>
          <ul class="space-y-3">
            <li><a href="<?php echo esc_url( home_url( '/about' ) ); ?>" class="text-slate-400 hover:text-orange-400 transition-colors duration-200">About Us</a></li>
            <li><a href="<?php echo esc_url( home_url( '/blog' ) ); ?>" class="text-slate-400 hover:text-orange-400 transition-colors duration-200">Blog</a></li>
            <li><a href="<?php echo esc_url( home_url( '/process' ) ); ?>" class="text-slate-400 hover:text-orange-400 transition-colors duration-200">Our Process</a></li>
            <li><a href="<?php echo esc_url( home_url( '/contact' ) ); ?>" class="text-slate-400 hover:text-orange-400 transition-colors duration-200">Contact</a></li>
          </ul>
        </div>
        <!-- Services -->
        <div>
          <h4 class="text-sm font-semibold text-white uppercase tracking-wider mb-4">Services</h4>
          <ul class="space-y-3">
            <li><a href="<?php echo esc_url( home_url( '/services' ) ); ?>" class="text-slate-400 hover:text-orange-400 transition-colors duration-200">All Services</a></li>
            <li><a href="<?php echo esc_url( home_url( '/quote' ) ); ?>" class="text-slate-400 hover:text-orange-400 transition-colors duration-200">Get a Quote</a></li>
            <li><a href="<?php echo esc_url( home_url( '/pricing' ) ); ?>" class="text-slate-400 hover:text-orange-400 transition-colors duration-200">Pricing</a></li>
          </ul>
        </div>
        <!-- Contact -->
        <div>
          <h4 class="text-sm font-semibold text-white uppercase tracking-wider mb-4">Contact Us</h4>
          <ul class="space-y-3">
            <li class="flex items-center space-x-2 text-slate-400"><span>📧</span><span>hello@arunalogistics.com</span></li>
            <li class="flex items-center space-x-2 text-slate-400"><span>📞</span><span>+1 (555) 123-4567</span></li>
            <li class="flex items-center space-x-2 text-slate-400"><span>📍</span><span>Mumbai, Maharashtra, India</span></li>
          </ul>
        </div>
      </div>
    </div>
    <!-- Copyright -->
    <div class="border-t border-slate-800">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col md:flex-row justify-between items-center">
        <p class="text-slate-500 text-sm">&copy; <?php echo date('Y'); ?> Aruna Logistics Solution. All rights reserved.</p>
        <div class="flex space-x-6 mt-4 md:mt-0">
          <a href="#" class="text-slate-500 hover:text-slate-300 text-sm transition-colors">Privacy Policy</a>
          <a href="#" class="text-slate-500 hover:text-slate-300 text-sm transition-colors">Terms of Service</a>
        </div>
      </div>
    </div>
    <?php wp_footer(); ?>
  </footer>
</body>
</html>
